/* cycle1.c */
#include <stdio.h>
#include <sys/time.h>
#include "cycle.h"

linkedList* createList(int N){
        srand(time(NULL));
        linkedList* ls = (linkedList*)myalloc(sizeof(linkedList*));
        ls->head = (Node *)myalloc(sizeof(Node*));
        (ls->head->element) = (int *)myalloc(sizeof(int*));
        *(int*)(ls->head->element) = rand()%1000;
        ls->size = 1;
        Node* curr = ls->head;
        for(int i=0;i<N-1;i++){
                Node* temp = (Node *)myalloc(sizeof(Node*));
                curr->next = temp;
                ls->size = ls->size + 1;
                curr->element = (int *)myalloc(sizeof(int*));
                *(int *)(curr->element) = rand()%1000;
                temp->next = NULL;
                if(curr->next) curr = curr->next;
        }
        ls->tail = curr;
        FILE* fptr;
        fptr = fopen("createListOutput.txt","w");
        fprintf(fptr,"Current memory allocated is : %ld\n",totalmem);
        fclose(fptr);
        return ls;
}

/*
void createCycle(linkedList * ls){
        int N = ls->size;
        srand(time(NULL)+1);
        if(rand()%2==0){
		printf("Cycling\n");
                int rr = rand()%1000;
                Node* curr = ls->head;
                while(*(int*)curr->element != rr) curr = curr->next;
                ls->tail->next = curr;
        }
}
*/

void createCycle(linkedList* ls){
	srand(time(NULL)+1);
	if(rand()%2){
		Node* current = ls->head;
		int r = rand()%1000;
		printf("%d\n",r);
		while(*(int*)current->element != r){
			current= current->next;
		}
		ls->tail->next = current;
	}
}


bool testCyclic(linkedList* ls){
        if(ls->size<3) return false;
	Node *turtle, *hare;
	hare = ls->head;
	turtle = ls->head;
	while(hare!=NULL && hare->next!=NULL){
		hare = hare->next->next;
		turtle = turtle->next;
		if(hare==NULL || turtle==NULL) return false;
		if(hare==turtle) return true;
	}
	return false;
}

/* end of cycle1.h */
