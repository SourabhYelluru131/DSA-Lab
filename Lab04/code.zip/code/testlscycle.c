/* testlscycle.c */
#include <stdio.h>
#include <stdlib.h>
#include "cycle.h"

int main(){
	int N = 1000000;
	linkedList* ls = createList(N);
	createCycle(ls);
	if(testCyclic(ls)) printf("True\n");
	else printf("False\n");
}

/* end of testlscycle.c */
