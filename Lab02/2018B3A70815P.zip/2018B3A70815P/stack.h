/* stack.h */
#include <stdio.h>
typedef struct linkedList Stack;
void push(Stack*, int ele);
struct node* pop(Stack*);
